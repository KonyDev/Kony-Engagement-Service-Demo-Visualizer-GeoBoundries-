//
//  LoggerAbstraction.h
//  LoggerAbstraction
//
//  Created by Harshini Bonam on 14/06/17.
//  Copyright © 2017 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LoggerAbstraction : NSObject

- (id)initWithLogger:(NSString *)loggerName;

+ (void)setConfig:(NSDictionary *) loggerConfig;

+ (void)setPersisterConfig:(NSDictionary *) persisterConfig;

+ (void)activatePersistors: (NSNumber*) persistorType;

+ (void)deactivatePersistors: (NSNumber*) persistorType;

/**-----------------------------------------------------------------------------
 * @name Main logging utilities through FFI layer.
 * -----------------------------------------------------------------------------
 */

/**
 * SET LOG LEVEL
 * @param logLevel logLevel to be set to logFilter
 */
+ (void)setLogLevel:(NSUInteger *)logLevel;

/**
 * GET LOG LEVEL
 * @return logLevel logLevel set to logFilter
 */
+ (int)getLogLevel;

/**
 * FLUSH the accumulated logs.
 */
+ (void)flush;
/**
 * TRACE statement
 * @param statement Statement to be logged
 */
- (void)logTrace:(NSDictionary *) statement;

/**
 * DEBUG statement
 * @param statement Statement to be logged
 */
- (void)logDebug:(NSDictionary *) statement;

/**
 * WARNING statement
 * @param statement Statement to be logged
 */
- (void)logWarning:(NSDictionary*) statement;

/**
 * INFO statement
 * @param statement Statement to be logged
 */
- (void)logInfo:(NSDictionary *) statement;

/**
 * ERROR statement
 * @param statement Statement to be logged
 */
- (void)logError:(NSDictionary *) statement;

/**
 * FATAL statement
 * @param statement Statement to be logged
 */
- (void)logFatal:(NSDictionary *) statement;

@end
